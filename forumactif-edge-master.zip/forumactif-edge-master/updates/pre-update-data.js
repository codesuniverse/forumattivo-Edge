// This file is used for testing updates before they go live
window.forumactif_edge_version_data = [
  '1.0.0-beta',
  '1.0.0-beta.1',
  '1.0.0',
  '1.0.1',
  '1.0.2',
  '1.1.0',
  '1.1.1',
  '1.1.2',
  '1.1.3',
  '1.1.4',
  '1.1.5'
];
